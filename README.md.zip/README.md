Project Organization
------------

    ├── LICENSE
    ├── README.md          <- The top-level README for developers using this project.
    ├── data
    │   ├── output         <- Output processed data
    │   └── raw            <- The original, immutable data dump.
    ├── notebooks          <- Jupyter notebooks
    └──  scripts            <- Python files
